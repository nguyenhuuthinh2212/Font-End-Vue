<template>
  <main class="container">
    <div>
      <product-list></product-list>
    </div>
  </main>
</template>

<script>
export default {
};
</script>

<style>
</style>
